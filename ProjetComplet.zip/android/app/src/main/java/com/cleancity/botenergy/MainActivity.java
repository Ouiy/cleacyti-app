package com.cleancity.botenergy;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
